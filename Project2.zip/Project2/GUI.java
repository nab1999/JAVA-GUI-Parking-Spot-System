/**
 * The GUI class serves as the main graphical user interface for the Parking Spot System. 
 * It facilitates various functionalities such as the addition and removal of parking slots, parking and finding cars, removal of unoccupied slots, and listing all parking slots with comprehensive details.
 * The class sets up the initial welcome window where users specify the number of slots (for staff and visitors), and then transitions into a main GUI which allows for management options in Parking Spot System. 
 * It also manages the dynamic updates of slot displays and incorporates interactive features (like mouse interactivity, scrolling, current time display, etc.).
 * 
 * This class utilizes Swing and AWT (Abstract Window Toolkit) components to construct and manage the interface elements, and handles events to ensure responsive and smooth user interactions.
 * By utilizing this GUI, users can effectively interact with the Parking Spot System to perform administrative and operational tasks.
 *
 *
 * @author (Nabeel Ahmed - 104502775)
 * @version (1.0)
 * @date (16/10/2024)
 */

// Importing swing components for GUI elements.
import javax.swing.*;
// Importing AWT components for building GUI and handling events.
import java.awt.*;
import java.awt.event.*;
// Importing Pattern class for regular expression operations.
import java.util.regex.Pattern;

// Importing classes for handling date and time operations.
import java.time.LocalDateTime; 
import java.time.Duration;   
import java.text.SimpleDateFormat;
import java.util.Date;

public class GUI extends JFrame {
    // Variables to hold the number of parking slots allocated for staff and visitors respectively.
    private int staffSlots;
    private int visitorSlots;
    
    // Text fields for initial user input of staff and visitor parking slots in the GUI.
    private JTextField staffField;
    private JTextField visitorField;
    
    // "mainSlotsPanel" to hold all the slots within the Main GUI window. And "menuPanel" to hold action buttons, instruction notes, and current time display within the Main GUI window.
    private JPanel mainSlotsPanel, menuPanel;
    
    // CarPark instance to manage parking slot operations within the GUI application.
    private CarPark carPark = new CarPark(); 
    
    /**
     * GUI Constructor which executes the initializeWelcomeGUI() method to run the Welcome GUI window.
     * 
     */
    public GUI() {
        initializeWelcomeGUI();
    }

    
    
     /**
     * The initializeWelcomeGUI() method initializes and displays the Welcome GUI window for the parking spot system.
     * This setup includes input fields for visitors and staff slot numbers, and a submit button.
     * Upon valid input and submission, it transitions the user to the Main GUI application window.
     */ 
    private void initializeWelcomeGUI() {
        // Setting up the Welcome GUI window with title, size, alignment, and layout configuration.
        setTitle("Parking Spot System");
        setSize(500, 250);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 20));

        // Displaying a welcome message in Welcome GUI window.
        JLabel welcomeLabel = new JLabel("Welcome! Please enter the number of parking slots.", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        // Panel for input fields.
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(2, 2, 10, 10));
        staffField = new JTextField(5);
        visitorField = new JTextField(5);
        inputPanel.add(new JLabel("Staff Slots:"));
        inputPanel.add(staffField);
        inputPanel.add(new JLabel("Visitor Slots:"));
        inputPanel.add(visitorField);

        // Submit button in Welcome GUI window.
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> submitSlots()); // Calling submitSlots() method when the submit buttton is clicked.

        // Adding components to the Welcome GUI frame.
        add(welcomeLabel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);
        
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // Setting window closing operation for Welcome GUI to do nothing, as the window listener below will handle this action.
        
        // This window listener handles the Welcome GUI and Main GUI window closing operation to ensure proper application exit.
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApp();   // The exitApp() method is called to handle window closing operation.
            }
        });
        
        setVisible(true); // Makes the Welcome GUI window visible.
    }
    
    
    
    /**
     * The IntegerValidate() method first converts the string input to integer and then validates if its a positive integer or not.
     * 
     * @param input The string input to validate.
     * @return true if the input is a positive integer, false otherwise.
     */
    private boolean IntegerValidate(String input) {
        try {
            int number = Integer.parseInt(input);  // Converting string input to integer.
            return number > 0; // Return true only if the number is greater than zero (positive integer).
        } catch (NumberFormatException e) {
            return false;  // Return false if input is not a valid integer.
        } 
    } 
    
    
    
    /**
     * The submitSlots() method submits and stores the parking slot counts entered by the user in the "staffSlots" and "visitorSlots" variables.
     * It also validates the inputs to ensure they are positive integers before proceeding.
     * If validation passes, it then removes the Welcome GUI window and initializes the Main GUI window. 
     * If validation fails, it displays an error message to user.
     */
    private void submitSlots() {
        // Validates that both inputs are positive integers.
        if (IntegerValidate(staffField.getText()) && IntegerValidate(visitorField.getText())) {  // If validation passes.
            // Parsing the validated inputs into integers and then storing them into their respective variables.
            staffSlots = Integer.parseInt(staffField.getText());
            visitorSlots = Integer.parseInt(visitorField.getText());
            
            // Transitioning from Welcome GUI to the Main GUI.
            removeWelcomeGUI(); // Removing Welcome GUI window.
            initializeMainGUI(); // Initializing Main GUI window.
        } else { // If validation fails
            // Showing error message dialog to user.
            JLabel alertMessage = new JLabel("Please enter valid positive integers for both staff and visitor slots!");
            alertMessage.setForeground(Color.RED); 
            JOptionPane.showMessageDialog(this, alertMessage, "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   
    
    /**
     * The removeWelcomeGUI() method removes all components from the Welcome GUI window.
     * This method is typically called before initializing a new Main GUI window, ensuring that the window is cleared of previous components.
     */    
    private void removeWelcomeGUI() {
        setVisible(false);  // Hiding the window to prevent flickering during the changes.
        getContentPane().removeAll();  // Removing all GUI components from the content pane.
        repaint();  // Refreshing the window to ensure any remains are cleaned up.
    }
    
    
    
    /**
     * The initializeMainGUI() method initializes and displays the Main GUI for the parking spot system.
     * This includes setting up buttons for parking management actions, instruction notes, and a dynamic time display in "menuPanel" panel.
     * Initializes and configures the "mainSlotsPanel" panel for representing all the slots in the parking spot system.
     * It also configures the layout and behavior of the "mainSlotsPanel" and "menuPanel" panels.
     */  
    private void initializeMainGUI() {
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize window on opening.
        setLayout(new BorderLayout(10, 10)); // Setting the main layout.
    
        // **************************************** Menu Panel Configuration ****************************************************************************************
        
         // Initializing the menu panel with a vertical layout to hold buttons.
        menuPanel = new JPanel(new GridLayout(10, 1, 5, 5)); // Has 10 rows and 1 column.
        
        // ^^^^^^^^^^^^^^^^^ Adding all buttons for parking management actions: ^^^^^^^^^^^^^^^^^^^^
        
        // 1. Add Parking Slot Button.
        JButton addParkingSlotButton = new JButton("Add Parking Slot");
        addParkingSlotButton.addActionListener(e -> addParkingSlot());   // Using Action Listener to call addParkingSlot().
        menuPanel.add(addParkingSlotButton);
        
        // 2. Remove Parking Slot Button.
        JButton removeParkingSlotButton = new JButton("Remove Parking Slot");
        removeParkingSlotButton.addActionListener(e -> removeParkingSlot());    // Using Action Listener to call removeParkingSlot().
        menuPanel.add(removeParkingSlotButton);
        
        // 3. List All Slots Button.
        JButton listAllSlots = new JButton("List All Slots");
        listAllSlots.addActionListener(e -> displayAllSlots());    // Using Action Listener to call displayAllSlots().
        menuPanel.add(listAllSlots);  
        
        // 4. Delete All Unoccupied Slots Button.
        JButton deleteUnoccupiedSlotsButton = new JButton("Delete All Unoccupied Slots");
        deleteUnoccupiedSlotsButton.addActionListener(e -> deleteAllUnoccupiedSlots());    // Using Action Listener to call deleteAllUnoccupiedSlots().
        menuPanel.add(deleteUnoccupiedSlotsButton); 
        
        // 5. Park Car Button.
        JButton parkCarButton = new JButton("Park Car");
        parkCarButton.addActionListener(e -> parkingCar());     // Using Action Listener to call parkingCar().
        menuPanel.add(parkCarButton); 
        
        // 6. Find a car by registration number Button.
        JButton findCarButton = new JButton("Find Car");
        findCarButton.addActionListener(e -> findCar());   // Using Action Listener to call findCar().
        menuPanel.add(findCarButton);         
        
        // 7. Remove a parked car by registration number Button.
        JButton removeCarButton = new JButton("Remove Car");
        removeCarButton.addActionListener(e -> removeCar());   // Using Action Listener to call removeCar().
        menuPanel.add(removeCarButton);         
        
        // 8. Exit Application Button.
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> exitApp());    // Using Action Listener to call exitApp().
        menuPanel.add(exitButton);  
        
        // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ End of Buttons ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        
        
        // Adding note panel to the menu panel.
        JPanel notePanel = new JPanel();
        notePanel.setBorder(BorderFactory.createTitledBorder("Advanced Interaction Note")); // Setting a titled border.
        
        // Using HTML in JLabel to format note text. 
        JLabel instructionLabel = new JLabel( "<html>" + "&#10070; Double left-click on a slot to add/remove a car.<br/>" +  "&#10070; Right-click to remove a slot.<br/>" +  
                                                            "&#10070; Automatically enables scrolling when the number of parking slots exceeds the display capacity." + "</html>");
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Setting font properties.
        notePanel.add(instructionLabel);
        menuPanel.add(notePanel);  // Adding notePanel to menuPanel.
               
 
        // Current Time Display.
        JLabel timeLabel = new JLabel("Time: " + getCurrentTime(), SwingConstants.CENTER);
        timeLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        menuPanel.add(timeLabel);
        updateClock(timeLabel); // Starting the clock update timer.
 
        
        // ****************************************************************** End of Menu Panel Configuration ******************************************************************
        
        // Creating and configuring "mainSlotsPanel" panel.
        mainSlotsPanel = new JPanel(new GridLayout(0, 3, 10, 10)); // GridLayout for flexible rows based on content.
        JScrollPane scrollPane = new JScrollPane(mainSlotsPanel); // Wrapping the mainSlotsPanel in a JScrollPane for scrolling feature.
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                
        
        initializeParkingSlots(); // The initializeParkingSlots() is called to add initial specified parking spots (based on staffSlots and visitorSlots variables) to "slots" ArrayList in CarPark Class.
        updateSlotsDisplay(); // Displays the slots in "mainSlotsPanel" panel within the Main GUI window.
        
        // Adding "menuPanel" and "scrollPane" panels to the Main GUI window frame.
        add(menuPanel, BorderLayout.WEST);  // menuPanel on the left side of the window.
        add(scrollPane, BorderLayout.CENTER);  // scrollPane in the center of the window.
        
        // Main GUI Window configuration.
        setLocationRelativeTo(null);
        revalidate();
        repaint();
        setVisible(true);
        
        
        // Setting the Main GUI window's close operation to do nothing, as the window listener in "initializeWelcomeGUI()" will handle (as it's still active) this closing operation for both windows.
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
         
    }
    
    
    
    /**
     * The getCurrentTime() method retrieves the current system time formatted as HH:mm:ss.
     * 
     * @return A string representation of the current time in hours, minutes, and seconds.
     */   
    private String getCurrentTime() {
        return new SimpleDateFormat("HH:mm:ss").format(new Date());   // Formating the current date and time.
    }

    
    
    /**
     * The updateClock() method initializes a timer to update the provided JLabel with the current time every second.
     * This method helps in displaying a live clock in the Main GUI window frame.
     *
     * @param timeLabel The JLabel to update with the current time.
     */
    private void updateClock(JLabel timeLabel) {
        // Creating a timer that calls the action listener every 1000 milliseconds (1 second).
        Timer timer = new Timer(1000, e -> {
            // Setting the text of the timeLabel to the current time.
            timeLabel.setText("Time: " + getCurrentTime());
        });
        timer.start();  // Starting the timer to begin updating the label.
    }
    
    
    
    /**
     * The initializeParkingSlots() method initializes the parking slots for both staff and visitors and then adds them to the parking spot system.
     * Staff slots are prefixed with 'S', and visitor slots are prefixed with 'V'.
     */
    private void initializeParkingSlots() {
        for (int i = 0; i < staffSlots; i++) {
            // Adding to parking spot system or ArrayList (slots) in CarPark Class.
            carPark.addSlot(new ParkingSlot("S" + String.format("%02d", i + 1), true));  // Staff slots are prefixed with 'S', and then followed by digits.
        }
        for (int i = 0; i < visitorSlots; i++) {
             // Adding to parking spot system or ArrayList (slots) in CarPark Class.
            carPark.addSlot(new ParkingSlot("V" + String.format("%02d", i + 1), false));  // Visitor slots are prefixed with 'V', and then followed by digits.
        }
    }

    
    
    /**
    * The updateSlotsDisplay() method updates the display of all parking slots in the "mainSlotsPanel" panel within the Main GUI window frame.
     * It also adds functionality to interact with slots through mouse clicks, allowing to remove a particular slot (if not occupied) and add/remove car in a particular slot.
     */
    private void  updateSlotsDisplay() {
        // Removing all previous components from the mainSlotsPanel, in order to update.
        mainSlotsPanel.removeAll();
    
        for (ParkingSlot slot : carPark.getSlots()) {
            // Creating and configuring panel for each slot present in the parking spot system.
            JPanel slotPanel = new JPanel(); // Panel for each slot.
            slotPanel.setLayout(new BoxLayout(slotPanel, BoxLayout.Y_AXIS));
            slotPanel.setBorder(BorderFactory.createLineBorder(Color.black, 2));
    
            // Determining and configuring background color based on slot occupancy and type.
            if (slot.isOccupied()) {
                Color occupiedColor = new Color(255,99,71);  // Custom color created with RGB for occupied slots.
                slotPanel.setBackground(occupiedColor); // Setting color for Occupied slots.
            } else if (slot.isStaffSlot()) {
                Color staffColor = new Color(244,164,96);  // Custom color created with RGB for unoccupied staff slot.
                slotPanel.setBackground(staffColor); // Setting color for Unoccupied staff slots.
            } else {
                Color visitorColor = new Color(176,196,222);  // Custom color created with RGB for unoccupied visitor slot.
                slotPanel.setBackground(visitorColor); // Setting color for Unoccupied visitor slots.
            }
    
            // Adding labels for slot details (slot ID, type, and occupancy status).
            JLabel idLabel = new JLabel("Slot ID: " + slot.getSlotID());
            idLabel.setFont(new Font("Arial", Font.BOLD, 16));
            JLabel typeLabel = new JLabel("Type: " + (slot.isStaffSlot() ? "Staff" : "Visitor"));
            typeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            JLabel occupiedLabel = new JLabel("Occupied: " + (slot.isOccupied() ? "Yes" : "No"));
            occupiedLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            slotPanel.add(idLabel);
            slotPanel.add(typeLabel);
            slotPanel.add(occupiedLabel);
            
            
            // If the slot is occupied, then it adds additional details and 'See Details' button.
            if (slot.isOccupied()) {
                Car parkedCar = slot.getParkedCar();
                
                // Showing Car registration number.
                JLabel carRegLabel = new JLabel("Car: " + parkedCar.getRegistrationNumber());
                carRegLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                slotPanel.add(carRegLabel);
                
                // Showing the time when the car is parked.
                JLabel parkedTimeLabel = new JLabel("Car Parked At: (" + parkedCar.getParkedTimeString() + ")");
                parkedTimeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                slotPanel.add(parkedTimeLabel);
                
                // Adding and configuring 'See Details' Button.
                JButton detailsButton = new JButton("See Details");
                detailsButton.addActionListener(e -> {
                    showCarDetails(parkedCar, slot);  // Using Action Listener to call showCarDetails() method for more details.
                });
                slotPanel.add(detailsButton);
            }
            
            
            // Adding Mouse listener to handle clicks for slot interaction in "mainSlotsPanel" panel.
            slotPanel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e)) {
                        clickRemoveSlot(slot); // Right-click to remove slot.
                    } else if (e.getClickCount() == 2) {
                        clickAddRemoveCar(slot); // Double left-click to add/remove car.
                    }
                }
            });
            
            mainSlotsPanel.add(slotPanel);  // Adding each slot panel to the mainSlotsPanel.
        }
     
        mainSlotsPanel.revalidate(); // Tells the layout manager to recalculate the layout.
        mainSlotsPanel.repaint(); // Refreshing the panel to display the updated slots.
    }
    
    
    
    /**
     * The clickRemoveSlot() method handles the removal of a parking slot when right-clicked, with confirmation from the user.
     * The slot can only be removed if it is not occupied.
     *
     * @param slot The parking slot to be removed.
     */
    private void clickRemoveSlot(ParkingSlot slot){
        if (!slot.isOccupied()) { // If the slot is not occupied.
            // Asking user for confirmation before removing the slot.
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove the parking slot (" + slot.getSlotID() + ") ?", "Confirm Removal", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) { 
                // Setting the success message.
                JLabel alertMessage = new JLabel("Parking Slot (" + slot.getSlotID() + ") Removed Successfully!");
                alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
                
                // Removing the slot.
                carPark.removeSlot(slot.getSlotID());
                
                updateSlotsDisplay(); // Refreshing the parking slots display (mainSlotsPanel).
                JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE); // Displaying success message in Dialog to the user.
            } else {
                // Handles the case where user decides not to remove the car.
                JOptionPane.showMessageDialog(this, "Parking Slot Removal Cancelled.", "Cancelled", JOptionPane.INFORMATION_MESSAGE);   // Displaying cancelled message in Dialog.
            }            
            
        } else { // If the slot is occupied.
            // Notifying the user.
            JLabel alertMessage = new JLabel("Cannot Remove Occupied Slot (" + slot.getSlotID() + ")!");
            alertMessage.setForeground(Color.RED); 
            JOptionPane.showMessageDialog(this, alertMessage, "Error", JOptionPane.ERROR_MESSAGE);  // Displaying the message to the user.
        }   
    }
    
    

    /**
     * The clickAddRemoveCar() method handles adding or removing a car from a parking slot when double left-clicked.
     * If the slot is occupied, it asks for confirmation to remove the car.
     * If the slot is empty, it parks a car in the slot.
     * 
     * @param slot The parking slot being interacted with.
     */    
    private void clickAddRemoveCar(ParkingSlot slot) {
        if (slot.isOccupied()) { // Handles car removal if the slot is occupied.
            // Asking user for confirmation before removing the car.
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove the car (" + slot.getParkedCar().getRegistrationNumber() + ") ?", "Confirm Removal", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) { // If user has confirmed car removal.
                // Proceed with removing the car if the user confirms:
                // Setting success message for the user.
                JLabel alertMessage = new JLabel("Car (" + slot.getParkedCar().getRegistrationNumber() + ") Removed Successfully!");
                alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
                
                carPark.removingCar(slot.getParkedCar().getRegistrationNumber()); // Removing the parked car.

                updateSlotsDisplay(); // Refreshing the parking slots display (mainSlotsPanel).
                JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);  // Displaying success message to user.
            } else {
                // Handles the case where user decides not to remove the car.
                JOptionPane.showMessageDialog(this, "Car Removal Cancelled.", "Cancelled", JOptionPane.INFORMATION_MESSAGE);  // Displaying cancelled message.
            }   
            
        } else {  // Parks a car if the slot is not occupied.
            // Creating and configuring the frame for parking a car.
            JFrame frame = new JFrame("Park a Car");
            frame.setSize(700, 250);
            frame.setLayout(new GridLayout(0, 2, 10, 10));  // Grid layout
            frame.setLocationRelativeTo(null);
    
            // Car Registration input components.
            JLabel regLabel = new JLabel("Enter Car Registration Number (e.g., A1234):");
            JTextField regField = new JTextField();
            frame.add(regLabel);
            frame.add(regField);
    
            // Owner Name input components.
            JLabel ownerLabel = new JLabel("Enter Owner Name:");
            JTextField ownerField = new JTextField();
            frame.add(ownerLabel);
            frame.add(ownerField);
    
            // Adding components in frame for Owner Type input.
            JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Sub-panel with flow layout for better control over radio buttons.
            JLabel staffLabel = new JLabel("Is the owner a staff member? (yes/no):");
            JRadioButton staffButton = new JRadioButton("Yes", true);
            JRadioButton visitorButton = new JRadioButton("No");
            ButtonGroup group = new ButtonGroup();
            group.add(staffButton);
            group.add(visitorButton);
            radioPanel.add(staffButton);
            radioPanel.add(visitorButton);
            frame.add(staffLabel);
            frame.add(radioPanel);
    
            // Button to submit the details.
            JButton submitButton = new JButton("Park Car");
            frame.add(submitButton);
            JLabel messageLabel = new JLabel(" ");  // Label for displaying messages
            frame.add(messageLabel);
                    
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  // Disposing frame on close.
            frame.setVisible(true);  // Displaying the frame.

            // Setting up the button's action listener.
            submitButton.addActionListener(e -> {
                String registrationNumber = regField.getText().trim(); // Stores the registration number.
                String ownerName = ownerField.getText().trim();  // Stores the owner name.
                boolean isStaff = staffButton.isSelected(); // Direct boolean from the RadioButton.
            
                messageLabel.setForeground(Color.RED);  // Setting default message color to red for errors.
            
                // Validating user input.
                
                // 1. Checking for empty fields.
                if (registrationNumber.isEmpty()) {
                    messageLabel.setText("Registration number cannot be empty!");
                    return;
                }
                
                if (ownerName.isEmpty()) {
                    messageLabel.setText("Owner name cannot be empty!");
                    return;
                }
                
                // 2. Validating  registration number format.
                if (!Pattern.matches("[A-Z][0-9]{4}", registrationNumber)) {
                    messageLabel.setText("Invalid format for registration number!");
                    return;
                }
                
                // 3. Validating if the car is already parked or not.
                if (carPark.checkCar(registrationNumber)) {
                    messageLabel.setText("Car with this registration is already parked!");
                    return;
                }
                
                // 4. Validating Slot type.
                if (slot.isStaffSlot() != isStaff) {
                    messageLabel.setText("Slot type mismatch!");
                    return;
                }
        
                // If all validation passes, the car will be parked in that slot.
                Car newCar = new Car(registrationNumber, ownerName, isStaff);
                carPark.parkingCar(registrationNumber, slot, newCar);
                frame.dispose(); // Closing the frame if successful.
                updateSlotsDisplay(); // Refreshing the parking slots display (mainSlotsPanel).
                // Notifying the user of success.
                JLabel alertMessage = new JLabel("Car (" + registrationNumber + ") parked successfully!");
                alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
                JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);  // Displaying success message.
            });    
        }
    }

    
    
    /**
     * The showCarDetails() method displays detailed information about a parked car and its associated parking slot.
     * The details include the car's registration number, owner's name, parking duration, and the calculated parking fee.
     *
     * @param car  The car object containing its details.
     * @param slot The parking slot where the car is parked.
     */
    private void showCarDetails(Car car, ParkingSlot slot) {
        // Getting the parked duration in seconds, and converting it to hours, minutes, and seconds.
        long seconds = slot.getParkingDurationInSeconds();
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long sec = seconds % 60;

        // Representing the car details in HTML format for better readability in the dialog.
        String details = "<html><b>Car Registration:</b> " + car.getRegistrationNumber() +
                         "<br/><b>Owner:</b> " + car.getCarOwner() +
                         "<br/><b>Parked Duration:</b> " + hours + " hours, " + minutes + " minutes, " + sec + " seconds" +
                         "<br/><b>Parking Fee:</b> $" + slot.calculateParkingFee() + "</html>";
                         
        // Displaying the details in a message dialog.
        JOptionPane.showMessageDialog(null, details, "Car Details", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    
    /**
     * The addParkingSlot() method adds a new parking slot in the parking spot system using the GUI window frame.
     * It validates user input for slot ID and type, and then adds the slot to the parking spot system if the validation is successful.
     */
    private void addParkingSlot() {
        // Setting a JFrame for adding a parking slot.
        JFrame frame = new JFrame("Add Parking Slot");
        frame.setSize(700, 250);  // Width and Height in pixels.
        frame.setLayout(new GridLayout(4, 2, 5, 5));
        frame.setLocationRelativeTo(null);
    
        // Slot ID components.
        JLabel slotIdLabel = new JLabel("Slot ID (For example, 'S01', 'V01', etc.):");
        JTextField slotIdField = new JTextField();
    
        // Slot type components.
        JLabel slotTypeLabel = new JLabel("Is this a staff slot? (yes/no):");
        JTextField slotTypeField = new JTextField();
    
        // Button to submit the slot details.
        JButton submitButton = new JButton("Add Slot");
        JLabel messageLabel = new JLabel();
        messageLabel.setForeground(Color.RED);
    
        // Adding components to frame.
        frame.add(slotIdLabel);
        frame.add(slotIdField);
        frame.add(slotTypeLabel);
        frame.add(slotTypeField);
        frame.add(new JLabel()); 
        frame.add(submitButton);
        frame.add(messageLabel);
    
        // Displaying the frame.
        frame.setVisible(true);
    
        // Defining action for the submit button.
        submitButton.addActionListener(e -> {

            String slotID = slotIdField.getText(); // Storing slot ID.
            String isStaffSlot = slotTypeField.getText().trim().toLowerCase(); // Storing slot type.
            boolean staffSlot;  // Storing slot type as boolean.
    
            // Checking for empty fields.
            if (slotID.isEmpty()) {
                messageLabel.setText("Slot ID cannot be empty!");
                return;
            }
            if (isStaffSlot.isEmpty()) {
                messageLabel.setText("Please specify if this is a staff slot (yes or no)!");
                return;
            }
            
            
            // Validating slot ID.
            if (!Pattern.matches("[A-Z][0-9]{2}", slotID)) {
                messageLabel.setText("Invalid Slot ID format! (For example, 'S01', 'V01', etc.)");
                return;
            }
            if (carPark.findSlot(slotID) != null) {
                messageLabel.setText("Slot ID already exists!");
                return;
            }
    
            
            // Validating slot type input (yes or no).
            if ("yes".equals(isStaffSlot)) {
                staffSlot = true;
            } else if ("no".equals(isStaffSlot)) {
                staffSlot = false;
            } else {
                messageLabel.setText("Type 'yes' or 'no' for slot type!");
                return;
            }
            
            
            // Validating slot type based on Slot ID prefix:
            // 1. For Staff.
            if (slotID.startsWith("S")) {
                if (!"yes".equals(isStaffSlot)) {
                    messageLabel.setText("Slot type does not match!");
                    return;
                } 
            } 
            // 1. For Visitors.
            if (slotID.startsWith("V")) {
                if (!"no".equals(isStaffSlot)) {
                    messageLabel.setText("Slot type does not match!");
                    return;
                }
            } 
            

            // If validation passes, then slot is added to the "ParkingSlot" ArrayList in CarPark Class or in other words in the Parking Spot System.
            carPark.addSlot(new ParkingSlot(slotID, staffSlot));
            updateSlotsDisplay();  // Updating slots panel.
            frame.dispose();  // Closing the window after successful addition.
            
            //Notifying the user for successfully adding the parking slot.
            JLabel alertMessage = new JLabel("Parking slot added successfully!");
            alertMessage.setForeground(new Color(0, 128, 0)); // Set the color to green
            JOptionPane.showMessageDialog(frame, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
   
        });
    }
    
    
    
    /**
     * The removeParkingSlot() method provides a GUI for users to remove a parking slot by entering its ID. 
     * It also validates the input and will remove the slot if it is found and not currently occupied.
     */
    private void removeParkingSlot() {
        // Creating and configuring a new JFrame for slot removal.
        JFrame frame = new JFrame("Remove Parking Slot");
        frame.setLayout(new GridLayout(4, 1, 5, 10)); // Has layout with 4 rows.
        frame.setSize(400, 220);
        frame.setLocationRelativeTo(null);
    
        // Components for user input.
        JLabel instructionLabel = new JLabel("Enter Slot ID to remove (e.g., S01):");
        JTextField slotIdField = new JTextField();
        JButton removeButton = new JButton("Remove Slot");
        JLabel messageLabel = new JLabel("");
        messageLabel.setForeground(Color.RED);
    
        // Adding components to the frame.
        frame.add(instructionLabel);
        frame.add(slotIdField);
        frame.add(removeButton);
        frame.add(messageLabel);
    
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Disposing frame on close.
        frame.setVisible(true); // Showing the frame.
    
        // Action for the remove button.
        removeButton.addActionListener(e -> {  // Triggering action listener when the button is clicked.
            String slotID = slotIdField.getText().trim(); // Storing slot ID.
            
            // Validating empty input for Slot ID.
            if (slotID.isEmpty()) {
                messageLabel.setText("Slot ID cannot be empty!");
                return;
            }
    
            // Validating Slot ID format.
            if (!Pattern.matches("[A-Z][0-9]{2}", slotID)) {
                messageLabel.setText("Invalid Slot ID format! (For example, 'S01', 'V01', etc.)");
                return;
            }
    
            // Confirmation dialog before removing the slot.
            int confirm = JOptionPane.showConfirmDialog(frame, 
                    "Are you sure you want to remove slot " + slotID + "?", 
                    "Confirm Deletion", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
    
            if (confirm == JOptionPane.YES_OPTION) { // If the user confirms to remove.
                // Validating and Removing the slot.
                if (carPark.removeSlot(slotID)) { // If the removeSlot() method removes the slot successfully.
                    JLabel alertMessage = new JLabel("Parking slot removed successfully!");
                    alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
                    JOptionPane.showMessageDialog(frame, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
    
                    updateSlotsDisplay(); // Updating the parking slots panel.
                    frame.dispose(); // Closing the frame.
                } else { // If the slot removal is unsuccessful.
                    messageLabel.setText("Failed to remove slot! (might be occupied or not found)");
                }
            } else { // If the user does not confirm for removing.
                // Brings back to remove slot window and clears any previous alert messages (displayed to user) for better user experience.
                messageLabel.setText(""); // Clearing any previous error messages.
            }
        });
    }


 
    /**
     * The displayAllSlots() method displays a GUI window listing all parking slots and their details.
     * Information includes slot ID, type, occupancy, car details, parking duration, and parking fees. 
     */
    private void displayAllSlots() {
         // Creating and configuring a new JFrame for displaying all slots.
        JFrame frame = new JFrame("All Parking Slots");
        frame.setSize(1200, 600); 
        frame.setLocationRelativeTo(null); 
    
        // Creating a text area to display slot information.
        JTextArea textArea = new JTextArea(20, 50); // Has 20 rows and 50 columns.
        textArea.setEditable(false); // Making text area non-editable.
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12)); 
    
        // Adding Scroll Pane in case of overflow.
        JScrollPane scrollPane = new JScrollPane(textArea);
        frame.add(scrollPane);
    
        // Populating the text area with slot details.
        if (carPark.getSlots().isEmpty()) {  // If not slots found.
            textArea.setText("* No parking slots are available!");
        } else { // If slots found.
            //Formating details of a each slot for display.
            StringBuilder sb = new StringBuilder("-------------------------- List Of All Parking Slots ------------------------------------------------------------------------------------------------\n");
            for (ParkingSlot slot : carPark.getSlots()) {
                sb.append("Slot ID: ").append(slot.getSlotID());
                sb.append(", Type: ").append(slot.isStaffSlot() ? "Staff" : "Visitor");
                sb.append(", Occupied: ").append(slot.isOccupied() ? "Yes" : "No");
    
                if (slot.isOccupied() && slot.getParkedCar() != null) {
                    Car parkedCar = slot.getParkedCar();
                    long seconds = slot.getParkingDurationInSeconds();
                    long hours = seconds / 3600;
                    long minutes = (seconds % 3600) / 60;
                    long sec = seconds % 60;
    
                    sb.append(", Car Registration: ").append(parkedCar.getRegistrationNumber());
                    sb.append(", Owner: ").append(parkedCar.getCarOwner());
                    sb.append(", Parked Duration: ").append(hours).append(" hours ");
                    sb.append(minutes).append(" minutes and ").append(sec).append(" seconds");
                    sb.append(", Parking Fee: $").append(slot.calculateParkingFee());
                }
    
                sb.append("\n");
            }
            sb.append("-----------------------------------------------------------------------------------------------------------------------------------------------------");
            textArea.setText(sb.toString());
        }
        
        // Setting the cursor to the start of the text to ensure the scrollbar starts at the beginning (for better user experience).
        textArea.setCaretPosition(0);
    
        frame.setVisible(true); // Showing the frame.
    }
   
    
    
    /**
     * The deleteAllUnoccupiedSlots() method deletes all unoccupied parking slots from the parking spot system and updates the GUI display.
     * It first asks for user confirmation before proceeding. If the user confirmed, it deletes the unoccupied slots and notifies the user of the outcome through a message dialog.
     */
    private void deleteAllUnoccupiedSlots() {
        // Asking the user for confirmation before deleting unoccupied slots.
        int confirm = JOptionPane.showConfirmDialog(this,
                                                    "Are you sure you want to delete all unoccupied parking slots?",
                                                    "Confirm Deletion",
                                                    JOptionPane.YES_NO_OPTION,
                                                    JOptionPane.WARNING_MESSAGE);
    
        if (confirm == JOptionPane.YES_OPTION) { // If user confirms deletion.
            boolean slotsRemoved = carPark.deleteAllUnoccupiedSlots(); // The method in "CarPark" Class that deletes unoccupied slots.
            if (slotsRemoved) { // If the slots removal is done successfully.
                updateSlotsDisplay(); // Updating parking slots GUI display.
                // Notifying the user for successfully removing the unoccupied parking slots.
                JLabel alertMessage = new JLabel("All unoccupied slots have been successfully deleted!");
                alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
                JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else { // If the slots removal was unsuccessful.
                // Notifying the user if no unoccupied slots were found to delete.
                JOptionPane.showMessageDialog(this, "No unoccupied slots were found to delete!", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        } else { // If user cancels the action.
            // Returns to the Main GUI window frame.
        }
    }

    
    
    /**
     * The parkingCar() method sets up the GUI for parking a car.
     * It also validates and includes input fields for slot ID, car registration, owner name, and owner type.
     */
    private void parkingCar() {
        // Creating and configuring a new JFrame for parking a car.
        JFrame frame = new JFrame("Park a Car");
        frame.setSize(900, 300);
        frame.setLayout(new GridLayout(0, 2, 10, 10));  // Grid layout for organizing display.
        frame.setLocationRelativeTo(null);
    
        // Adding components in frame for Slot ID input.
        JLabel slotIdLabel = new JLabel("Enter Slot ID (e.g., S01, V01):");
        JTextField slotIdField = new JTextField();
        frame.add(slotIdLabel);
        frame.add(slotIdField);
    
        // Adding components in frame for Car Registration input.
        JLabel regLabel = new JLabel("Enter Car Registration Number (e.g., A1234):");
        JTextField regField = new JTextField();
        frame.add(regLabel);
        frame.add(regField);
    
        // Adding components in frame for Owner Name input.
        JLabel ownerLabel = new JLabel("Enter Owner Name:");
        JTextField ownerField = new JTextField();
        frame.add(ownerLabel);
        frame.add(ownerField);
        
        // Adding components in frame for Owner Type input.
        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Sub-panel with flow layout for better control over radio buttons.
        JLabel staffLabel = new JLabel("Is the owner a staff member? (yes/no):");
        JRadioButton staffButton = new JRadioButton("Yes", true);
        JRadioButton visitorButton = new JRadioButton("No");
        ButtonGroup group = new ButtonGroup();
        group.add(staffButton);
        group.add(visitorButton);
        radioPanel.add(staffButton);
        radioPanel.add(visitorButton);
        frame.add(staffLabel);
        frame.add(radioPanel);
    
        // Adding Button to submit or perform action to park the car.
        JButton submitButton = new JButton("Park Car");
        frame.add(submitButton);
        JLabel messageLabel = new JLabel(" ");  // Label for displaying messages.
        frame.add(messageLabel);
        
        // Window frame configuration.
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    
        // Setting up the submit button's action listener.
        submitButton.addActionListener(e -> {
            String slotID = slotIdField.getText().trim();  // Storing slot ID.
            String registrationNumber = regField.getText().trim();  // Storing registration number.
            String ownerName = ownerField.getText().trim(); // Storing owner name.
            boolean isStaff = staffButton.isSelected(); // Direct boolean from the RadioButton.
            
            messageLabel.setForeground(Color.RED);  // Setting default message color to red for errors.
    
            // Validating inputs:
    
            // 1. Checking if all slots are occupied or not.
            if (carPark.checkAllSlotsOccupied()) {
                messageLabel.setText("All parking slots are currently occupied or not available! (Please try again later...)");
                return;
            }
            
            // 2. Checking for empty fields.
            if (slotID.isEmpty()) {
                messageLabel.setText("Slot ID cannot be empty!");
                return;
            }
            
            if (registrationNumber.isEmpty()) {
                messageLabel.setText("Registration Number cannot be empty!");
                return;
            }
            
            if (ownerName.isEmpty()) {
                messageLabel.setText("Owner Name cannot be empty!");
                return;
            }
            
            
            // 3. Validating slot ID and registration number format.
            if (!Pattern.matches("[A-Z][0-9]{2}", slotID) || !Pattern.matches("[A-Z][0-9]{4}", registrationNumber)) {
                messageLabel.setText("Invalid format! (either for slot ID or registration number)");
                return;
            }
            
            
            // 4. Validating slot ID.
            ParkingSlot slot = carPark.findSlot(slotID);   // Calling findSlot method to find the slot by ID.
            if (slot == null || slot.isOccupied()) {
                messageLabel.setText("Slot either not found or already occupied! (Please try with different Slot ID..)");
                return;
            }
            
            // 5. Validating if the car is already parked or not.
            if (carPark.checkCar(registrationNumber)) {
                messageLabel.setText("Car with this registration is already parked!");
                return;
            }
            
            // 6. Validating slot type.
            if (slot.isStaffSlot() != isStaff) {
                messageLabel.setText("Slot type mismatch!");
                return;
            }
    
            // If all validation passes, the car is parked in the specified slot in the parking spot system.
            Car newCar = new Car(registrationNumber, ownerName, isStaff);
            carPark.parkingCar(registrationNumber, slot, newCar);
            frame.dispose(); 
            updateSlotsDisplay();
       
            // Displaying success message to the user.
            JLabel alertMessage = new JLabel("Car parked successfully!");
            alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.
            JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
        });        
    }    
    
    

    /**
     * The findCar() method initializes the GUI for finding a parked car by its registration number.
     * Allows users to enter a registration number and displays car details or error messages based on user input.
     */
    private void findCar() {
        // Creating and configuring a new JFrame for finding a parked car.
        JFrame frame = new JFrame("Find a Parked Car");
        frame.setSize(500, 250);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    
        // Layout setup.
        frame.setLayout(new BorderLayout(5, 5));  
    
        // Input panel components and configuration.
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JLabel regLabel = new JLabel("Enter Car Registration Number (e.g., A1234):");
        JTextField regField = new JTextField(10);
        JButton findButton = new JButton("Find Car");
        inputPanel.add(regLabel);
        inputPanel.add(regField);
        inputPanel.add(findButton);
    
        // Output panel components and configuration. (For displaying results)
        JPanel outputPanel = new JPanel();
        outputPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JLabel messageLabel = new JLabel(" ");
        outputPanel.add(messageLabel);
    
        // Adding Input and Output panels in the window frame.
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(outputPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    
        // Setting up the action listener for the "Find Car" button.
        findButton.addActionListener(e -> {
            String registrationNumber = regField.getText().trim();  // Storing registration number.
            messageLabel.setForeground(Color.RED);  // Setting default message color to red for errors.
            
            // 1. Validating empty field for registration number.
            if (registrationNumber.isEmpty()) { 
                messageLabel.setText("Registration Number cannot be empty!");
                return;
            }
            
            // 2. Validating registration number format.
            if (!registrationNumber.matches("[A-Z][0-9]{4}")) {
                messageLabel.setText("Invalid registration number format!");
                return;
            }
    
            // Finding the parking slot by using the car's registration number.
            ParkingSlot slot = carPark.findSlotByRegistration(registrationNumber);  // The method returns the slot with that specifieed registration number if found.
            if (slot != null && slot.isOccupied()) { // Checking if slot exists and is occupied.
                // Retrieving the parked car's details from the slot.
                Car parkedCar = slot.getParkedCar();
                
                // Calculating the total parking duration in seconds and then converting into hours, minutes, and seconds.
                long seconds = slot.getParkingDurationInSeconds();
                long hours = seconds / 3600;
                long minutes = (seconds % 3600) / 60;
                long sec = seconds % 60;
    
                messageLabel.setForeground(new Color(0, 150, 0)); // Setting the color to green.
                foundParkingSlotsDisplay(hours, minutes, sec, registrationNumber); // Displaying the found car in the parking slots panel (in the Main GUI window frame).
                
                // Displaying results on the same "Find a Parked Car" window frame.
                messageLabel.setText("<html><b>Car Found:</b> <br/> -> Slot: " + slot.getSlotID() +
                                     "<br/> -> Owner: " + parkedCar.getCarOwner() +
                                     "<br/> -> Parked Duration: " + hours + " hours, " + minutes + " minutes, " + sec + " seconds" +
                                     "<br/> -> Parking Fee: $" + slot.calculateParkingFee() + "</html>");
            } else { // If the car was not found.
                //Notifying the user if the car is not found.
                messageLabel.setText("Car with registration number (" + registrationNumber + ") not found or not currently parked!");
            }
        });
        
        // Adding window listener to handle window closing event.
        frame.addWindowListener(new WindowAdapter() { 
            // When window is closed by the user, it will close "Find a Parked Car" frame and refreah the slots panel (in Main GUI window frame).
            @Override
            public void windowClosing(WindowEvent e) {
                updateSlotsDisplay();  // Updating slots panel.
                frame.dispose();  // Closing "Find a Parked Car" frame.
            }
        });       
    }
    
    
    
    /**
     * The foundParkingSlotsDisplay() method updates and highlights the slot containing the searched car in "mainSlotsPanel" panel.
     * @param hours Hours the searched car has been parked.
     * @param minutes Minutes the searched car has been parked.
     * @param seconds Seconds the searched car has been parked.
     * @param searchedRegNumber Registration number of the searched car.
     */
    public void foundParkingSlotsDisplay(long hours,  long minutes, long seconds, String searchedRegNumber ) {
        mainSlotsPanel.removeAll(); // Clearing the display of existing slots in "mainSlotsPanel" panel.
        
        for (ParkingSlot slot : carPark.getSlots()) {
            // Creating and configuring the slot panel.
            JPanel slotPanel = new JPanel();
            slotPanel.setBorder(BorderFactory.createLineBorder(Color.black));
            
            // Adding details to slot panel if not occupied.
            String details = "<html>Slot ID: " + slot.getSlotID() +
                             "<br>Type: " + (slot.isStaffSlot() ? "Staff" : "Visitor") +
                             "<br>Occupied: " + (slot.isOccupied() ? "Yes" : "No");
           
            // Adding details to slot panel if occupied.
            if (slot.isOccupied()) {
                Car car = slot.getParkedCar();
                details += "<br>Car: " + car.getRegistrationNumber() +
                           "<br>Owner: " + car.getCarOwner() +
                           "<br>Parked Duration: " + hours + " hours, " + minutes + " minutes, " + seconds + " seconds" +
                           "<br>Parking Fee: $" + slot.calculateParkingFee();
                if (car.getRegistrationNumber().equals(searchedRegNumber)) {
                    // Highlighting the slot if it contains the searched car.
                    slotPanel.setBackground(Color.YELLOW); 
                }
            }
            details += "</html>";  // End of adding further details.
            slotPanel.add(new JLabel(details)); // Adding components to the slot panel.
            mainSlotsPanel.add(slotPanel); // Adding the slot panel to the "mainSlotsPanel" panel within the Main GUI frame.
        }
        // Restructuring the "mainSlotsPanel" panel frame accordingly.
        mainSlotsPanel.revalidate();
        mainSlotsPanel.repaint();
    }
    
    
    
    /**
     * The removeCar() method sets up a GUI for users to remove a parked car by entering its registration number.
     * It also validates the registration number format and attempts to remove the car if it is found, after confirming with the user.
     */
    private void removeCar() {
        // Creating and configuring a new JFrame for "Remove a Parked Car" process.
        JFrame frame = new JFrame("Remove a Parked Car");
        frame.setSize(500, 200);
        frame.setLayout(new GridLayout(3, 1));  // Simple grid layout
        frame.setLocationRelativeTo(null);
    
        // Input components for car registration number.
        JPanel inputPanel = new JPanel(new FlowLayout());
        JLabel regLabel = new JLabel("Enter Car Registration Number (e.g., A1234):");
        JTextField regField = new JTextField(10);
        inputPanel.add(regLabel);
        inputPanel.add(regField);
        frame.add(inputPanel);
    
        // Status message label configuration.
        JLabel messageLabel = new JLabel(" ");
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(messageLabel);
    
        // Remove Car Button.
        JButton removeButton = new JButton("Remove Car");
        frame.add(removeButton);
        
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Closing "Remove a Parked Car" frame, when user closes the window.
        frame.setVisible(true); // Displaying the "Remove a Parked Car" frame.
        messageLabel.setForeground(Color.RED);  // Setting default message color to red for errors.
    
        // Action listener for the remove button.
        removeButton.addActionListener(e -> {
            String regNumber = regField.getText().trim(); // Storing registration number.
    
            // Validating empty input for Registration Number.
            if (regNumber.isEmpty()) {
                messageLabel.setText("Registration Number cannot be empty!");
                return;
            }
            
            // Validating Registration Number Format.
            if (!regNumber.matches("[A-Z][0-9]{4}")) {
                messageLabel.setText("Invalid Registration Number Format!");
                return;
            }
            
            // Asking for user confirmation before removing the car.
            int confirm = JOptionPane.showConfirmDialog(frame,
                                                        "Are you sure you want to remove the car with registration number (" + regNumber + ")?",
                                                        "Confirm Removal",
                                                        JOptionPane.YES_NO_OPTION,
                                                        JOptionPane.WARNING_MESSAGE);
    
            if (confirm == JOptionPane.YES_OPTION) {
                boolean carRemoveStatus = carPark.removingCar(regNumber);  // Removing the parked car and storing the progress result as boolean.
                if (carRemoveStatus) { // If the parked car is removed successfully.
                    // Notifying the user of successful removal of the parked car.
                    JLabel alertMessage = new JLabel("Car (" + regNumber + ") removed successfully!");
                    alertMessage.setForeground(new Color(0, 128, 0)); // Setting the color to green for success message.

                    updateSlotsDisplay(); // Refreshing the parking slots display (mainSlotsPanel).
                    // Displaying the success message to user.
                    JOptionPane.showMessageDialog(this, alertMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
                    messageLabel.setText(""); // Clears any previous alert messages (for better user experience).
                } else { // If the parked car is not removed successfully.
                    // Notifying the user of unsuccessful removal of the parked car.
                    messageLabel.setText("Failed to remove a car! (It may not be found or already removed)");
                }
            } else { // If the user does not confirm the removal of the car.
                // Brings the user back to the parked car removal window.
                messageLabel.setText(""); // Clears any previous alert messages (for better user experience).
            }
        });
    }


    
    /**
     * The exitApp() method asks the user for confirmation and exits the application if confirmed.
     * This method ensures that the user has a chance to confirm their intention before the application closes, preventing accidental exits.
     * If the user selects "No", the application remains running.
     */
    private void exitApp() {
        // Confirms the user if they really want to exit the application or not, by asking to click/select yes or no options.
        int confirmed = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit the program?", "Exit Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
       

        if (confirmed == JOptionPane.YES_OPTION) {  // If "Yes" is selected, it exits the application.
            System.exit(0);
        } 
        
          // If "No" is selected, the method simply returns and does nothing.
    }    
    

    
    /**
     * Main method to run the GUI program for the Parking Spot System.
     */
    public static void main(String[] args) {
        // Creating an instance of the GUI, which will run the GUI constractor for starting this program.
        new GUI(); 
    }
    
    
}

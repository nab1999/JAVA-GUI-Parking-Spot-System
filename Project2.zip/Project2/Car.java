/**
 * This class represents a car parked in a parking spot. 
 * It stores the car's registration number, owner's name, staff status, and the time the car was parked.
 *
 * @author (Nabeel Ahmed - 104502775)
 * @version (1.0)
 * @date (07/09/2024)
 */

import java.time.LocalDateTime;   // Importing LocalDateTime for handling date and time.
import java.time.format.DateTimeFormatter;  // Importing DateTimeFormatter for formatting dates and times in a human-readable form.

public class Car
{
    private String regNumber;  // Car's registration number.
    private String carOwner;   // Owner's name of the car.
    private boolean isStaff;    // Variable/Flag indicating whether the owner is a staff member.
    private LocalDateTime parkedTime;  // Storing datetime when the car was parked.
    
    
    /**
     * "Car" constructor creates a new Car instance with the specified details.
     * 
     * @param regNumber the registration number of the car.
     * @param carOwner the name of the car's owner.
     * @param isStaff true if the owner is a staff member, false otherwise (visitor).
     */
    public Car(String regNumber, String carOwner, boolean isStaff) {
        this.regNumber = regNumber;
        this.carOwner = carOwner;
        this.isStaff = isStaff;
        this.parkedTime = LocalDateTime.now(); // Captures the current time as parked time.
    }

    
    
    /**
     * Get method that returns the car's registration number.
     * 
     * @return the registration number of the car.
     */
    public String getRegistrationNumber() {
        return regNumber;
    }

    
    
    /**
     * Get method that returns the name of the car's owner.
     * 
     * @return the owner's name.
     */
    public String getCarOwner() {
        return carOwner;
    }

    
    
    /**
     * Method that checks if the car's owner is a staff member.
     * 
     * @return true if the owner is a staff member, otherwise false.
     */
    public boolean isStaff() {
        return isStaff;
    }
    
    
    
    /**
     * Get method that returns the datetime when the car was parked.
     * 
     * @return the parked datetime.
     */
    
    public LocalDateTime getParkedTime() {
        return parkedTime;
    }

    
    
    /**
     * Get method that returns a formatted string of the parked datetime.
     * 
     * @return the parked datetime in "yyyy-MM-dd HH:mm:ss" format.
     */
    public String getParkedTimeString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return parkedTime.format(formatter);
    }

}

/**
 * The Application class handles the user interface for the Parking Spot System.
 * It provides a console-based menu to interact with the program to manage parking slots and cars.
 * 
 * @author (Nabeel Ahmed - 104502775)
 * @version (1.0)
 * @date (07/09/2024)
 */

import java.util.Scanner;    // Importing Scanner class for user input.
import java.util.regex.Pattern; // Importing Pattern class for regular expression operations.


public class Application {
    
    // Initializing a CarPark object to manage parking slots & cars, and a Scanner object for handling console input.
    private static CarPark carPark = new CarPark();
    private static Scanner sc = new Scanner(System.in);

    /**
     * Main method that runs and controls the the parking spot program.
     */
    
    public static void main(String[] args) {
        System.out.println("**** Welcome to Car Parking Spot System ****\n");
        initializeCarPark();  // Setting up initial parking slots and configurations by calling initializeCarPark method.
        boolean runProgram = true;  // Variable that is used as a condition for running and stopping main program. 
        System.out.println("-----------------------------------------------\n");
        
        
        // While loop that continuously run the whole parking spot program until user selects to exit/stop.
        while (runProgram == true) {
            showMenu();  // Displays menu items to user.
            
            boolean validChoice = false;   // For validation purpose.
            int choice = getIntInput("-> Select: ");   // Storing user's input for menu selection.
    
            // Validating to ensure that user select only from given menu options.
            while (!validChoice){
                
                 if (choice > 8 || choice < 1){
                    choice = getIntInput("* Please select from option 1 to 8 only!\n \n-> Select: ");
                    } 
                    else{
                        validChoice = true;
                    }
            } 
            
            // Switch statement used to control the execution of methods corresponding to menu choices.
            switch (choice) {
                case 1:
                    addParkingSlot(); // Calling method to add a parking slot.
                    break;
                case 2:
                    removeParkingSlot(); // Calling method to delete a parking slot by slot ID.
                    break;
                case 3:
                    carPark.getAllSlots(); // Calling method to list all slots.
                    break;
                case 4:
                    boolean slotsRemoved = carPark.deleteAllUnoccupiedSlots();  // Calling method that deletes all unoccupied parking slots and returns a boolean output.
                    // Displaying output based on boolean result received from the "carPark.deleteAllUnoccupiedSlots" method.
                    if(slotsRemoved){
                    System.out.println("* All unoccupied slots have been successfully deleted! \n");}
                    else{
                    System.out.println("* No unoccupied slots were found to delete! \n");}
                    break;
                case 5:
                    parkingCar(); // Calling method to park a car into a slot.
                    break;
                case 6:
                    findCar();  // Calling method to find a car by registration number.
                    break;
                case 7:
                   removeCar(); // Calling method to remove a car by registration number.
                    break;
                case 8:
                    System.out.println("* Program end!");  // Exiting the program.
                    runProgram = false;
                    break;
                default:
                    System.out.println("* Invalid option, please try again!");   // Default to handle input which are not from given options.
                    break;
            }
        }
    }
    
    
    
    /**
     * The "initializeCarPark" method initializes the car park with a specified number of staff and visitor slots.
     * Users are asked to enter the number of each type of slot, and the method dynamically creates and adds these slots to the car park.
     */
    private static void initializeCarPark() {
        // Getting the number of staff and vistor parking slots to initialize by using getIntInput method (which allows to get only positive integers from user).
        int staffSlots = getIntInput("-> Enter the number of staff slots:");
        int visitorSlots = getIntInput("-> Enter the number of visitor slots:");
        
        // Looping through the number of staff slots and adding each to the car park.
        for (int i = 0; i < staffSlots; i++) {
            carPark.addSlot(new ParkingSlot("S" + String.format("%02d", i + 1), true));  // Slot IDs are formatted sequentially (as 'S01', 'S02', etc.) and assigned with slot type (where 'true' indicates a staff slot).
        }
        // Looping through the number of visitor slots and adding each to the car park.
        for (int i = 0; i < visitorSlots; i++) {
            carPark.addSlot(new ParkingSlot("V" + String.format("%02d", i + 1), false));  // Slot IDs are formatted sequentially (as 'V01', 'V02', etc.) and assigned with slot type (where 'false' indicates a visitor slot).

        }
    }

    
    
    /**
     * The "showMenu" method displays the main menu options to the user. Each option corresponds to a specific operation in the parking spot system.
     */
    private static void showMenu() {
        System.out.println("\n************** Menu Items: **************");
        System.out.println("\n1. Add a parking slot.");
        System.out.println("2. Delete a parking slot by slot ID.");
        System.out.println("3. List all slots.");
        System.out.println("4. Delete all unoccupied parking slots.");
        System.out.println("5. Park a car into a slot.");
        System.out.println("6. Find a car by registration number.");
        System.out.println("7. Remove a car by registration number.");
        System.out.println("8. Exit Program.");
        System.out.println("*****************************************");
    }
    
    
    
    /**
     * The "addParkingSlot" method allows user to add a new parking slot. 
     * It also ensures that the slot ID is unique and correctly formatted before adding to the parking system.
     */
    private static void addParkingSlot() {
        String slotID = "";  // For storing Slot ID.
        String isStaffSlot = "";  // Stores info regarding if the slot is for staff or not.
        
        // Variables for validation purpose.
        boolean validSoltID = false;
        boolean validStaffSlot = false;
        boolean staffSlot = false;
        
        // 1. User Input for Slot ID:
        // Using while-loop until valid and unique SlotID is entered by user.
        while (!validSoltID) {
            System.out.println("-> Enter Slot ID (For example, 'S01', 'V01', etc.)");
            slotID = sc.nextLine();
            
            // Validating the SlotID format.
            if (!Pattern.matches("[A-Z][0-9]{2}", slotID)) {
                System.out.println("* Invalid Slot ID format. Slot ID must start with a capital letter followed by two digits (e.g., S01, V01). \n");
                continue; 
            }
            
            // Checking if the SlotID already exists.
            if (carPark.findSlot(slotID) != null) {
                System.out.println("* Slot ID already exists! Please enter a unique Slot ID. \n");
                continue; 
            }
            
            validSoltID = true; // Exiting loop when valid and unique SlotID entered.
        }
        
        // 2. User Input for Slot type (staff or not):
        System.out.println("-> Is this a staff slot? (yes/no):");
        
        // Using while-loop until a valid staff slot input ("yes" or "no") is provided by the user.
        while (!validStaffSlot) {
            isStaffSlot = sc.nextLine().trim().toLowerCase();
            switch (isStaffSlot) {
                case "yes":   
                    staffSlot= true; // Setting the staff slot flag to true if the user confirms the slot is for staff.
                    validStaffSlot = true;  // Marking input as valid to exit the loop.
                    break;
                case "no":
                    staffSlot= false;  // Setting the staff slot flag to false if the user confirms the slot is not for staff.
                    validStaffSlot = true; // Marking input as valid to exit the loop.
                    break;
                default:
                    System.out.println("* Invalid input! Please type 'yes' or 'no'. \n");    // Default to handle input which is not "yes" or "no".
                }
            }
        
        // 3. Adding the new parking slot to the car park.
        carPark.addSlot(new ParkingSlot(slotID, staffSlot));
        System.out.println("\n* Parking slot added successfully! \n");
    }
        
       
        
    /**
     * The "removeParkingSlot" method allows user to remove a parking slot by specify the Slot ID.
     * It also validates or check if the slot can be removed or not, and provides feedback based on the outcome.
     */  
    private static void removeParkingSlot() {
        boolean validSoltID = false;  // Variable for validation.
        String slotID = ""; // For storing Slot ID.

        while (!validSoltID) {
            System.out.println("\n-> Enter Slot ID to remove (For example, 'S01', 'V01', etc.): ");
            slotID = sc.nextLine();
            
            // Validating the SlotID format.
            if (!Pattern.matches("[A-Z][0-9]{2}", slotID)) {
                System.out.println("\n* Invalid Slot ID format. Slot ID must start with a capital letter followed by two digits (e.g., S01, V01).");
                continue; 
            }
            
            validSoltID = true; // Exiting loop when valid SlotID entered.
        }

        // Displaying the appropriate message based on the boolean result received from "carPark.removeSlot(slotID)" method.
        if (carPark.removeSlot(slotID)) {  // The "removeSlot" method returns True if the Slot with specified ID is removed, else it will return False.
            System.out.println("\n* Parking slot removed successfully! \n");
        } else {
            System.out.println("\n* Failed to remove parking slot (it might be occupied or not found)! \n");
        }
    }

    /**
     * The "parkingCar" method guides the user through the process of parking a car by obtaining necessary information
     * and validating it against the parking system's rules. 
     * It checks for slot availability, correct car registration format, car is already parked or not, and owner type info before parking the car.
     */

    private static void parkingCar() {
        // Variables for validation purpose.
        boolean validSlot = false;
        boolean validStaffSlot = false;
        boolean staffSlot = false;
        
        // Stores info regarding if the slot is for staff or not.
        String isStaffSlot = "";
        
        // 1. Checking if all slots are occupied before proceeding.
        if (carPark.checkAllSlotsOccupied()) {
            System.out.println("* All parking slots are currently occupied or not available! (Please try again later...)");
            return; // Return to the main menu.
        }
        
        // 2. Entering Slot ID for which the car will be parked.
        System.out.println("-> Enter Slot ID (e.g., S01, V01):");
        String slotID = sc.nextLine();   // Storing the user input for Slot ID.
        ParkingSlot slot = carPark.findSlot(slotID);   // Calling findSlot method to find the slot by ID.
        
        // 2.1 Validating to check if the slot exists or already occuppied.
        while(!validSlot){
            if (slot == null || slot.isOccupied()){
            System.out.println("* Slot either not found or already occupied! (Please try with different Slot ID..) \n");
            System.out.println("-> Enter Slot ID (e.g., S01, V01):");  // Asking the user to enter Slot ID again.
            slotID = sc.nextLine(); 
            slot = carPark.findSlot(slotID);
        }
        else{
        validSlot = true;}
        
        }
        
        // 3. Entering the car registeration number which will be parked.
        System.out.println("\n-> Enter Car Registration Number (e.g., A1234):");
        String regInput = sc.nextLine();   // Storing the car registeration input.
        
        // 3.1 Validating the car registeration number by using regular expression.
        while (!regInput.matches("[A-Z][0-9]{4}")) {  
            System.out.println("* Invalid input! Please enter a registration number that starts with a capital letter followed by four digits (e.g., A1234): \n");
            System.out.println("-> Enter Car Registration Number (e.g., A1234):");
            regInput = sc.nextLine();
        }
        
        // 3.2 Checking if the car is already parked or not.
        if (carPark.checkCar(regInput)) {  
            System.out.println("* Car with registration number (" + regInput + ") is already parked!"); // Statement executed if the car is already parked.
        } 
         // Statements executed if the car is not parked.
        else{  
            
            // 4. Entering Owner Name for that car.
            System.out.println("\n-> Enter Owner Name:");
            String owner = sc.nextLine();
            
            // 5. Entering owner type info regarding being a staff or not.
            System.out.println("\n-> Is the owner a staff member? (yes/no):");
            
            // 5.1 Validating user input for owner type info.
            while (!validStaffSlot) {
                isStaffSlot = sc.nextLine().trim().toLowerCase();
                switch (isStaffSlot) {
                    case "yes":
                        staffSlot= true;  // Assigning True value if the owner is staff.
                        validStaffSlot = true;  // Ensuring that validation is completed by assigning True value.
                        break;
                    case "no":
                        staffSlot= false;   // Assigning False value if the owner is not staff (visitor).
                        validStaffSlot = true;  // Ensuring that validation is completed by assigning True value.
                        break;
                    default:
                        System.out.println("* Invalid input! Please type 'yes' or 'no'. \n");
                }
            }
            
            // 5.2 Validating owner type info based on slot type entered.
            boolean validMember = false; // Variable for validation.
            
            // Looping until valid Owner Type info is entered based on Slot Type.
            while (!validMember){
                if ((slot.isStaffSlot() == staffSlot)) {  // If the parking slot type matches the owner type info, then following statements are executed.
                    Car newCar = new Car(regInput, owner, staffSlot); // Creating Car object as per entered info.
                    carPark.parkingCar(regInput, slot, newCar); //Parking the car to the specified slot.
                    System.out.println("* Car parked successfully at [" + newCar.getParkedTimeString() + "]. \n");  // Displaying car parked message along with the date/time when the car was parked.
                    validMember = true;  // Stopping loop.
                }
                else {  // If the parking slot type does not match the owner type info, then following statements are executed.
                    // Asking the user to enter valid owner type info again.
                    System.out.println("* Slot type mismatch! Please confirm the owner type again.... \n");
                    System.out.println("-> Is the owner a staff member? (yes/no):");
                    validStaffSlot = false;  // Changing flag to false for validation purpose.
                    // Validating user input for owner type info again.
                    while (!validStaffSlot) {
                        isStaffSlot = sc.nextLine().trim().toLowerCase();
                        switch (isStaffSlot) {
                            case "yes":
                                staffSlot= true;
                                validStaffSlot = true;
                                break;
                            case "no":
                                staffSlot= false;
                                validStaffSlot = true;
                                break;
                            default:
                                System.out.println("* Invalid input! Please type 'yes' or 'no'. \n");
                        }
                    }
                } 
            }
        }
    }
    
    
    
    /**
     * The "findCar" method searches for a car by its registration number and displays detailed information about its parking status if found. 
     * The output information includes the slot ID or location, owner, parked duration, and applicable parking fee.
     */              
    private static void findCar() {
        // User input for car registration number.
        System.out.println("Enter Car Registration Number:");
        String regNumber = sc.nextLine().trim();
        
        // Validating car registration number using regular expression.
        while (!regNumber.matches("[A-Z][0-9]{4}")) {  
            System.out.println("* Invalid input! Please enter a registration number that starts with a capital letter followed by four digits (e.g., A1234): \n");
            System.out.println("Enter Car Registration Number (e.g., A1234):");
            regNumber = sc.nextLine();
        }
        
        // Locating the parking slot by using the car's registration number.
        ParkingSlot slot = carPark.findSlotByRegistration(regNumber);
        
        if (slot != null && slot.isOccupied()) {  //If the slot is not empty and is occupied then the following statements are executed. 
            // Retrieving the parked car's details from the slot.
            Car parkedCar = slot.getParkedCar();
            
            // Displaying details about the car and its parking status.
            System.out.println("-------- Car With Registration Number (" + regNumber + ") Found: --------");
            System.out.println("\n -> Slot: " + slot.getSlotID());
            System.out.println("\n -> Owner: " + parkedCar.getCarOwner());
            
            // Calculating the total parking duration in seconds and then converting into hours, minutes, and seconds.
            long seconds = slot.getParkingDurationInSeconds();
            long hours = seconds / 3600;
            long minutes = (seconds % 3600) / 60;
            long sec = seconds % 60;
            
            // Displaying the parking duration and calculating the parking fee based on the duration.
            System.out.println("\n -> Parked Duration: " + hours + " hours, " + minutes + " minutes, and " + sec + " seconds.");
            System.out.println("\n -> Parking Fee: $" + slot.calculateParkingFee());
            
            System.out.println("\n-------------------------------------------------------------");
            
        } 
        else {
            // Notifying the user if no car matches the entered registration number or if it is not currently parked.
            System.out.println("* Car with registration number (" + regNumber + ") not found or or not currently parked!");
        }
    }
    
    
    
    /**
     * The "removeCar" method basically removes a car from the parking slot based on the provided registration number.
     * It also validates the input format for registration number and reports on the success or failure of the removal operation.
     */
    private static void removeCar() {
        // User input for car registration number.
        System.out.println("Enter the registration number of the car to remove:");
        String regNumber = sc.nextLine().trim(); 
        
        // Validation for car registration number using regular expression.
        while (!regNumber.matches("[A-Z][0-9]{4}")) {  // Regular expression to validate the input
            System.out.println("* Invalid input! Please enter a registration number that starts with a capital letter followed by four digits (e.g., A1234): \n");
            System.out.println("Enter Car Registration Number (e.g., A1234):");
            regNumber = sc.nextLine();
        }
        
        // Removing the car from the parking slot using the removingCar method (which returns True if the car is removed successfully, else it returns False).
        boolean carRemoveStatus = carPark.removingCar(regNumber);
        
        if (carRemoveStatus) {  // If the car is removed successfully.
            System.out.println("* Car with registration number (" + regNumber + ") has been successfully removed from its parking slot!");
        } else {   
            // Informing the user if the car could not be found or had already been removed.
            System.out.println("* Failed to remove the car with registration number (" + regNumber + ")! It may not be found or already removed...");
        }
    }


    
    /**
     * The "getIntInput" method is basically used to take a positive integer input and validates the input.
     *
     * @param message The message to display to the user when asking for input.
     * @return A validated positive integer entered by the user.
     */
    
    private static int getIntInput(String message) {
        int number = 0; // For storing the input.
        boolean isValidInput = false;  // Variable for validation purpose.
        System.out.println(message);
        
        // Looping until a valid positive integer is entered. 
        while (!isValidInput) {
            if (sc.hasNextInt()) { // Checks if the next input is an integer.
                number = sc.nextInt();
                sc.nextLine(); // Consuming the leftover newline character after the integer input.
                if (number > 0) {  // Checking if the integer is positive.
                    isValidInput = true; // Marking the input as valid if it's a positive integer.
                } else {
                    System.out.println("* Invalid input! Please enter a positive integer...\n");
                    System.out.println(message);
                }
            } else {
                sc.next(); // Discarding non-integer input.
                System.out.println("* Invalid input! Please enter only integers...\n");
                System.out.println(message);
            }
        }
        return number;  // Returning the validated positive integer.
    }
    
    
}


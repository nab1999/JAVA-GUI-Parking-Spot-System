/**
 * The CarPark class manages a collection of parking slots, providing functionalities to add, remove, and find slots based on slot ID or car registration number.
 * It also handles operations such as parking a car, checking for a parked car, removing a car, deleting all unoccupied slots, and listing all slots with their respective details.
 * 
 * @author (Nabeel Ahmed - 104502775)
 * @version (1.0)
 * @date (07/09/2024)
 */

// Imports for Map and HashMap (registration-to-slot associations).
import java.util.Map;  
import java.util.HashMap;  

// Imports for List and ArrayList (storing parking slots).
import java.util.ArrayList;  
import java.util.List;  


public class CarPark
{
    private List<ParkingSlot> slots;  // List to hold all parking slots.
    private Map<String, ParkingSlot> regNumberToSlotMap;  // Maps car registration numbers to their corresponding parking slots for quick lookup.
    
    
    /**
     * The CarPark constructor creates a CarPark instance initializing the list and map.
     */
    public CarPark() {
        slots = new ArrayList<>();
        regNumberToSlotMap = new HashMap<>();
    }

    
    
    /**
     * The addSlot method adds a new parking slot to the list of all the parking slots.
     * 
     * @param slot The new parking slot to be added.
     */
    public void addSlot(ParkingSlot slot) {
        slots.add(slot);
    }

    
    
    /**
     * The removeSlot method removes a parking slot by its ID if it is not currently occupied.
     * 
     * @param slotID The ID of the slot to be removed.
     * @return true if the slot was removed successfully, false otherwise.
     */  
    public boolean removeSlot(String slotID) {
        for (ParkingSlot slot : slots) {
            if (slot.getSlotID().equals(slotID) && !slot.isOccupied()) {
                slots.remove(slot);
                return true;
            }
        }
        
        return false;
    }
    
    
    
    /**
     * The findSlot method finds a parking slot by its ID.
     * 
     * @param slotID The ID of the slot to search for.
     * @return The found parking slot or null if no matching slot is found.
     */  
    public ParkingSlot findSlot(String slotID) {
        for (ParkingSlot slot : slots) {
            if (slot.getSlotID().equals(slotID)) {
                return slot;
            }
        }
        return null;
    }
    
    
    
    /**
     * The getAllSlots method prints all parking slots with detailed information including slot ID, type, occupancy, car details, parking duration, and fees.
     */
    public void getAllSlots() {
        if (slots.isEmpty()) {
            System.out.println("* No parking slots are available!");
        }
        else{
            System.out.println("------------- List Of All Parking Slots -----------------------------------------------------------------------------------------------------------------");
            for (ParkingSlot slot : slots) {
                System.out.print("Slot ID: " + slot.getSlotID());
                System.out.print(", Type: " + (slot.isStaffSlot() ? "Staff" : "Visitor"));
                System.out.print(", Occupied: " + (slot.isOccupied() ? "Yes" : "No"));
                if (slot.isOccupied() && slot.getParkedCar() != null) {
                    Car parkedCar = slot.getParkedCar();
                    System.out.print(", Car Registration: " + parkedCar.getRegistrationNumber());
                    System.out.print(", Owner: " + parkedCar.getCarOwner());

                    long seconds = slot.getParkingDurationInSeconds();
                    long hours = seconds / 3600;
                    long minutes = (seconds % 3600) / 60;
                    long sec = seconds % 60;
                    
                    System.out.print(", Parked Duration: " + hours + " hours " + minutes + " minutes and " + sec + " seconds");
                    System.out.print(", Parking Fee: $" + slot.calculateParkingFee());
                }
                
                System.out.println();
            }
            
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------");
        }
    }
    
    /**
     * The findSlotByRegistration method retrieves a parking slot by a car's registration number.
     * 
     * @param regNumber The registration number of the car.
     * @return The parking slot where the car is parked, or null if the car is not found.
     */ 
    public ParkingSlot findSlotByRegistration(String regNumber) {
        return regNumberToSlotMap.get(regNumber);  // Retrieving slot using registration number.
    }


    
    /**
     * The deleteAllUnoccupiedSlots method deletes all unoccupied parking slots from the system.
     * 
     * @return true if any slots were deleted, false if no slots were removed.
     */
    public boolean deleteAllUnoccupiedSlots(){
        List<ParkingSlot> toRemove = new ArrayList<>();  // Collecting the slots to remove in a separate list and then remove them all in one go. 
        
        for (ParkingSlot slot : slots) {
            if (!slot.isOccupied()) {
                toRemove.add(slot);  // Adding unoccupied slots to the toRemove list. 
            }
        }
        
        if (toRemove.isEmpty()) {
            return false; // Indicates that no slots were removed.
        }
        
        slots.removeAll(toRemove);  // Removing all unoccupied slots based on toRemove list. 
        return true;  // Indicates that all unoccupied slots have been deleted.
    }
    
    
    
    /**
     * The parkingCar method parks a car in a specified slot and records the car's registration in a lookup map.
     * 
     * @param regNumber The registration number of the car.
     * @param slot The slot where the car will be parked.
     * @param car The car to be parked.
     */  
    public void parkingCar(String regNumber, ParkingSlot slot, Car car) {
        slot.parkCar(car);  // Parks the car and marks the slot as occupied.
        regNumberToSlotMap.put(regNumber, slot);   // Adds to map for quick lookup.
    }
    
    
    
    /**
     * The checkCar method checks if a car with the given registration number is already parked or not.
     * 
     * @param regNumber The registration number to check.
     * @return true if the car is currently parked, false otherwise.
     */
    public boolean checkCar(String regNumber){
        return regNumberToSlotMap.containsKey(regNumber);  // Checks if the car is in the map.
    }
    
    
    
    /**
     * The removingCar method removes a car from its parking slot based on the registration number.
     * 
     * @param regNumber The registration number of the car to be removed.
     * @return true if the car was removed successfully, false if the car was not found or already removed.
     */
    public boolean removingCar(String regNumber){
        ParkingSlot slot = regNumberToSlotMap.get(regNumber); // Finding the parking slot associated with the given registration number.
        if (slot != null && slot.isOccupied()) {
            // Removing the car from the slot.
            slot.removeCar();              
            // Removing the registration number from the map.
            regNumberToSlotMap.remove(regNumber);
            return true;  // When the car is removed successfully.
        }
        else{
            return false;   // When no car with the given registration number is parked/found or it's already removed.
        }
    }
    
    
    
    /**
     * The checkAllSlotsOccupied method checks if all parking slots are currently occupied.
     * 
     * @return true if all slots are occupied, false otherwise.
     */
    public boolean checkAllSlotsOccupied() {
        for (ParkingSlot slot : slots) {
            if (!slot.isOccupied()) {
                return false; // Found at least one slot that is not occupied.
            }
        }
        return true; // When all slots are occupied.
    }

    
    
    
    //***************** Mehtods for GUI********************//

    /**
     * This getSlots method retrieves the list of all parking slots managed by the CarPark.
     *
     * @return A list containing all the parking slots currently managed by the CarPark.
     */
    public List<ParkingSlot> getSlots() {
        return slots; // Returns the current list of parking slots
    }
    
    
    
    

}

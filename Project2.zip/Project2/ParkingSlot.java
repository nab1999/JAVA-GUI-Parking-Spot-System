/**
 * The ParkingSlot class represents a parking slot in a Parking Spot System.
 * This class handles the details of a parking slot including its ID, occupancy status, the car parked (if any), and whether the slot is designated for staff members.
 * It also provides methods to park and remove cars, check if the slot is occupied, getting duration (seconds) of car parked, and calculate parking fees based on the duration the car has been parked.
 * 
 * @author (Nabeel Ahmed - 104502775)
 * @version (1.0) 
 * @date (07/09/2024)
 */


import java.time.LocalDateTime;  // Used to handle date and time operations.
import java.time.Duration;    // Utilized for calculating the duration between two LocalDateTime objects.


public class ParkingSlot
{
    private String slotID;  // Variable to store Slot ID.
    private boolean isOccupied;  // Variable/Flag to indicate whether the slot is occupied.
    private Car carParked;      // Storing Car object.
    private boolean isStaffSlot;  // Variable/Flag to indicate if the slot is reserved for staff members or not (visitor).
    
    
    /**
     * The ParkingSlot constructor creates a parking slot with a specific ID and designation for staff.
     *
     * @param slotID Unique identifier for the slot.
     * @param isStaffSlot Boolean indicating if the slot is for staff members.
     */
    public ParkingSlot(String slotID, boolean isStaffSlot) {
        this.slotID = slotID;
        this.isOccupied = false;
        this.carParked = null;
        this.isStaffSlot = isStaffSlot;
    }

    
    
    /**
     * The parkCar method parks a car in the slot, marking the slot as occupied.
     *
     * @param car The car to be parked in this slot.
     */
    public void parkCar(Car car) {
        this.carParked = car;  // Storing the car object.
        this.isOccupied = true;  // Marking the slot as occupied.
    }

    
    
    /**
     * The removeCar method removes the car from the slot and marks the slot as unoccupied.
     *
     * @return true if a car was successfully removed, otherwise false.
     */
    public boolean removeCar() {
        if (isOccupied) {
            this.carParked = null;
            this.isOccupied = false;
            return true;
        }
        return false;
    }

    
    // Get method for slot ID.
    public String getSlotID() {
        return slotID;
    }

    
    // Get method for occupancy status.
    public boolean isOccupied() {
        return isOccupied;
    }

    
    // Get method for parked car.
    public Car getParkedCar() {
        return carParked;
    }

    
    // Get method that returns true if the slot is for a staff member, otherwise false.
    public boolean isStaffSlot() {
        return isStaffSlot;
    }
    
    
    
    /**
     * The getParkingDurationInSeconds method calculates the parking duration in seconds since the car was parked.
     *
     * @return Total duration in seconds or 0 if no car is parked.
     */
    public long getParkingDurationInSeconds() {
        if (isOccupied && carParked != null) {
            Duration duration = Duration.between(carParked.getParkedTime(), LocalDateTime.now());  // Calculating duration.
            return duration.getSeconds(); // Getting total duration in seconds.
        }
        return 0;
    }

    
    
    /**
     * The calculateParkingFee method calculates the parking fee based on the duration the car has been parked.
     * Charges $5 per hour (less than 1 hour is charged as 1 hour).
     *
     * @return Calculated parking fee.
     */
    public double calculateParkingFee() {
        long totalSeconds = getParkingDurationInSeconds();
        long hours = totalSeconds / 3600; // Calculating the full hours from total seconds.
        if (totalSeconds % 3600 > 0) { // Checking if there are extra seconds beyond the full hours.
            hours++;  // Charging for an additional full hour if there are any extra seconds.
        }
        return hours * 5;  // Charging $5 per full or partial hour.
    }

}


